#!/usr/bin/env bash
# Publish the dist/ from this bundle as a new release on an already installed server (root):
#   curl -L -o a.tgz <bundle url> && rm -rf abof && tar xzf a.tgz && bash abof/deploy/update.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SITE_DIR=/var/www/abof
[ -d "$SITE_DIR/releases" ] || { echo "site is not installed yet, run install.sh instead"; exit 1; }
REL="$(date -u +%Y%m%d-%H%M%S)-bundle"
mkdir -p "$SITE_DIR/releases/$REL"
cp -a "$HERE/../dist/." "$SITE_DIR/releases/$REL/"
ln -sfn "releases/$REL" "$SITE_DIR/current.tmp" && mv -Tf "$SITE_DIR/current.tmp" "$SITE_DIR/current"
chown -R deploy:deploy "$SITE_DIR" 2>/dev/null || true
ls -1dt "$SITE_DIR"/releases/* | tail -n +6 | xargs -r rm -rf
systemctl reload nginx
echo "published release $REL"
