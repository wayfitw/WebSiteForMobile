#!/usr/bin/env bash
# One-time server setup for Ubuntu/Debian VPS (Aeza).
# Run as root:  DOMAIN=example.ru bash setup-server.sh
set -euo pipefail

DOMAIN="${DOMAIN:?Set DOMAIN=your.domain}"
EXTRA_DOMAINS="${EXTRA_DOMAINS:-}"          # optional, space-separated: EXTRA_DOMAINS="abof-iqter.online"
NAMES="$DOMAIN www.$DOMAIN"; for d in $EXTRA_DOMAINS; do NAMES="$NAMES $d www.$d"; done
DEPLOY_USER="${DEPLOY_USER:-deploy}"
SITE_DIR=/var/www/abof

echo "== 1. Packages"
apt-get update -q
apt-get install -y -q nginx rsync certbot python3-certbot-nginx ufw

echo "== 2. Deploy user (rsync target for CI / deploy.sh)"
if ! id "$DEPLOY_USER" &>/dev/null; then
  adduser --disabled-password --gecos "" "$DEPLOY_USER"
fi
mkdir -p "$SITE_DIR/releases" /home/"$DEPLOY_USER"/.ssh
chown -R "$DEPLOY_USER":"$DEPLOY_USER" "$SITE_DIR" /home/"$DEPLOY_USER"/.ssh
chmod 700 /home/"$DEPLOY_USER"/.ssh
echo "   -> add the deploy public key to /home/$DEPLOY_USER/.ssh/authorized_keys"

echo "== 3. nginx site"
sed "s/server_name DOMAIN www.DOMAIN;/server_name $NAMES;/" "$(dirname "$0")/nginx.conf" > /etc/nginx/sites-available/abof
ln -sf /etc/nginx/sites-available/abof /etc/nginx/sites-enabled/abof
rm -f /etc/nginx/sites-enabled/default
# placeholder release so nginx has something to serve before the first deploy
if [ ! -e "$SITE_DIR/current" ]; then
  mkdir -p "$SITE_DIR/releases/bootstrap"
  echo "<!doctype html><title>ABOF</title><p>Deploying…" > "$SITE_DIR/releases/bootstrap/index.html"
  ln -sfn "$SITE_DIR/releases/bootstrap" "$SITE_DIR/current"
  chown -R "$DEPLOY_USER":"$DEPLOY_USER" "$SITE_DIR"
fi
nginx -t && systemctl enable --now nginx && systemctl reload nginx

echo "== 4. Firewall"
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable

echo "== 5. HTTPS"
bash "$(dirname "$0")/ssl.sh" || true

echo "== Done. Next: put the public key into /home/$DEPLOY_USER/.ssh/authorized_keys and run deploy.sh"
