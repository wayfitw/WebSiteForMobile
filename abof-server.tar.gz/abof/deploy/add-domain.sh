#!/usr/bin/env bash
# Add one more domain to the site on this server and extend the HTTPS certificate.
# Run as root on the server after the domain's A-records (@ and www) point here:
#   bash add-domain.sh abof-iqter.ru
# PRIMARY=abof-iqter.ru bash add-domain.sh abof-iqter.ru   -> also make it the canonical host (others redirect to it)
set -euo pipefail
NEW="${1:?usage: add-domain.sh new.domain}"
CONF=/etc/nginx/sites-available/abof
[ -f "$CONF" ] || { echo "nginx site config $CONF not found; run setup-server.sh first"; exit 1; }

MY_IP="$(curl -4 -s --max-time 10 https://ifconfig.me || hostname -I | awk '{print $1}')"
for h in "$NEW" "www.$NEW"; do
  ip="$(getent ahostsv4 "$h" | awk 'NR==1{print $1}')"
  if [ "$ip" != "$MY_IP" ]; then
    echo "DNS: $h -> '${ip:-none}', this server is $MY_IP. Add A-records for @ and www, wait, re-run."; exit 1
  fi
done

# collect every server_name already present (certbot may have split the file into 80/443 blocks)
CURRENT="$(grep -hoE 'server_name[^;]+;' "$CONF" | sed 's/server_name//; s/;//' | tr ' ' '\n' | grep -v '^$' | sort -u | tr '\n' ' ')"
ALL="$(printf '%s %s www.%s' "$CURRENT" "$NEW" "$NEW" | tr ' ' '\n' | grep -v '^$' | sort -u | tr '\n' ' ' | sed 's/ $//')"
sed -i -E "s/server_name[^;]+;/server_name $ALL;/g" "$CONF"
nginx -t && systemctl reload nginx
echo "nginx now serves: $ALL"

ARGS=(); for d in $ALL; do ARGS+=(-d "$d"); done
certbot --nginx "${ARGS[@]}" --expand --non-interactive --agree-tos --register-unsafely-without-email --redirect

if [ -n "${PRIMARY:-}" ]; then
  LIVE="$(ls /etc/letsencrypt/live | grep -v README | head -1)"
  OTHERS="$(echo "$ALL" | tr ' ' '\n' | grep -vx "$PRIMARY" | tr '\n' ' ')"
  # HTTPS blocks of the main config serve only the canonical host; every other name gets a 301 to it.
  python3 - "$CONF" "$PRIMARY" <<'PY'
import re,sys
path,primary=sys.argv[1],sys.argv[2]; s=open(path).read(); out=[]; i=0
while True:
    m=re.search(r'\bserver\s*\{',s[i:])
    if not m: out.append(s[i:]); break
    a=i+m.start(); j=i+m.end(); depth=1
    while depth and j<len(s):
        depth+= {'{':1,'}':-1}.get(s[j],0); j+=1
    block=s[a:j]
    if re.search(r'listen\s+[^;]*443',block):
        block=re.sub(r'server_name[^;]+;','server_name '+primary+';',block)
    out.append(s[i:a]); out.append(block); i=j
open(path,'w').write(''.join(out))
PY
  cat > /etc/nginx/sites-available/abof-canonical <<CONF2
server {
    listen 443 ssl;
    listen [::]:443 ssl;
    server_name $OTHERS;
    ssl_certificate     /etc/letsencrypt/live/$LIVE/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$LIVE/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    return 301 https://$PRIMARY\$request_uri;
}
CONF2
  ln -sf /etc/nginx/sites-available/abof-canonical /etc/nginx/sites-enabled/abof-canonical
  nginx -t && systemctl reload nginx
  echo "canonical host: https://$PRIMARY (others redirect)"
fi
