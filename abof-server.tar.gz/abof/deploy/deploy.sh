#!/usr/bin/env bash
# Build locally and deploy dist/ to the server with an atomic release switch.
#   SSH_HOST=1.2.3.4 SSH_USER=deploy bash deploy/deploy.sh
# Optional: SSH_PORT (22), DEPLOY_PATH (/var/www/abof), KEEP (number of old releases, 5)
set -euo pipefail
cd "$(dirname "$0")/.."

SSH_HOST="${SSH_HOST:?Set SSH_HOST}"
SSH_USER="${SSH_USER:-deploy}"
SSH_PORT="${SSH_PORT:-22}"
DEPLOY_PATH="${DEPLOY_PATH:-/var/www/abof}"
KEEP="${KEEP:-5}"
REL="$(date -u +%Y%m%d-%H%M%S)"
TARGET="$SSH_USER@$SSH_HOST"
SSH="ssh -p $SSH_PORT -o StrictHostKeyChecking=accept-new"

echo "== build"
npm run build --silent

echo "== upload release $REL"
$SSH "$TARGET" "mkdir -p '$DEPLOY_PATH/releases/$REL'"
rsync -az --delete -e "$SSH" dist/ "$TARGET:$DEPLOY_PATH/releases/$REL/"

echo "== switch symlink + cleanup"
$SSH "$TARGET" "cd '$DEPLOY_PATH' \
  && ln -sfn 'releases/$REL' current.tmp && mv -Tf current.tmp current \
  && ls -1dt releases/* | tail -n +$((KEEP+1)) | xargs -r rm -rf"

echo "== done: $DEPLOY_PATH/current -> releases/$REL"
