#!/usr/bin/env bash
# Issue/renew the Let's Encrypt certificate once DNS points at this server.
#   DOMAIN=abof-iqter.online bash ssl.sh
set -uo pipefail
DOMAIN="${DOMAIN:?Set DOMAIN=your.domain}"
EXTRA_DOMAINS="${EXTRA_DOMAINS:-}"
MY_IP="$(curl -4 -s --max-time 10 https://ifconfig.me || hostname -I | awk '{print $1}')"
ARGS=()
for d in $DOMAIN $EXTRA_DOMAINS; do
  for h in "$d" "www.$d"; do
    DNS_IP="$(getent ahostsv4 "$h" | awk 'NR==1{print $1}')"
    if [ "$DNS_IP" != "$MY_IP" ]; then
      echo "DNS: $h -> '${DNS_IP:-none}', this server is $MY_IP. Fix the A-record, wait, then re-run:"
      echo "  DOMAIN=$DOMAIN EXTRA_DOMAINS='$EXTRA_DOMAINS' bash $(readlink -f "$0")"
      exit 1
    fi
    ARGS+=(-d "$h")
  done
done
certbot --nginx "${ARGS[@]}" --expand --non-interactive --agree-tos --register-unsafely-without-email --redirect
