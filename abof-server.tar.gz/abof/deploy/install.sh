#!/usr/bin/env bash
# All-in-one installer for a fresh VPS, run as root on the server:
#   scp abof-server.tar.gz root@SERVER:/root/ && ssh root@SERVER 'tar xzf abof-server.tar.gz && bash abof/deploy/install.sh'
# The bundle contains deploy/ (scripts, nginx config) and dist/ (the built site).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
export DOMAIN="${DOMAIN:-abof-iqter.ru}"
export EXTRA_DOMAINS="${EXTRA_DOMAINS-abof-iqter.online}"
SITE_DIR=/var/www/abof

bash "$HERE/setup-server.sh"

echo "== Publish the bundled build as the first release"
REL="$(date -u +%Y%m%d-%H%M%S)-bundle"
mkdir -p "$SITE_DIR/releases/$REL"
cp -a "$HERE/../dist/." "$SITE_DIR/releases/$REL/"
ln -sfn "releases/$REL" "$SITE_DIR/current.tmp" && mv -Tf "$SITE_DIR/current.tmp" "$SITE_DIR/current"
chown -R deploy:deploy "$SITE_DIR"
systemctl reload nginx

IP="$(hostname -I | awk '{print $1}')"
echo
echo "================================================================"
echo " Site is live:  http://$IP/   and  http://$DOMAIN/  (once DNS is set)"
echo " HTTPS: if DNS was not ready, run later:  DOMAIN=$DOMAIN EXTRA_DOMAINS='$EXTRA_DOMAINS' bash $HERE/ssl.sh"
echo " Deploy user 'deploy' created; add a public key to /home/deploy/.ssh/authorized_keys"
echo " Consider changing the root password now:  passwd"
echo "================================================================"
